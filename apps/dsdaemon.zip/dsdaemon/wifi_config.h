#ifndef  __WIFI_CONFIG__
#define __WIFI_CONFIG__

int read_wifi_default_config(void);
int save_new_wifi_config(void);

#endif

