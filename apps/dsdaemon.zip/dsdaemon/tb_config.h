#ifndef  __THINGSBOARD_CONFIG__
#define  __THINGSBOARD_CONFIG__

int save_apply_thingsboard();

#endif

