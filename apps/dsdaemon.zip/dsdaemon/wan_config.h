#ifndef  __WAN_CONFIG__
#define  __WAN_CONFIG__

int save_apply_new_wan_config(int);

#endif

