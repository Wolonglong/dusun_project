#ifndef  __LAN_CONFIG__
#define  __LAN_CONFIG__

int save_new_lan_config(void);

#endif

